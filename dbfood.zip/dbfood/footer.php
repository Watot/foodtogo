<div class="container-fluid animatedParent" style="background:#F8F9FA; padding:40px;"> 
		    <div class="container">
		      
			      <div class="row animated fadeIn">
				      
					  
					 
					  <div class="col-sm-6" >
					     <ul>
						  
						  <li><a href="food.php">+ADD FOODS</a></li>
						  
						</ul>
					  </div>
				  </div>
			 </div>
			 			 
		  </div>